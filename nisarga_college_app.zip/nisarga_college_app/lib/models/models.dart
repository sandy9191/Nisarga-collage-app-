import 'package:cloud_firestore/cloud_firestore.dart';

/// ---------- Student ----------
class StudentModel {
  final String uid;
  final String name;
  final String email;
  final String? photoUrl;
  final String? rollNumber;
  final String? course; // e.g. "B.Sc", "B.Com", "B.A"
  final String? year; // e.g. "1st Year"
  final bool isAdmin;
  final String? fcmToken;

  StudentModel({
    required this.uid,
    required this.name,
    required this.email,
    this.photoUrl,
    this.rollNumber,
    this.course,
    this.year,
    this.isAdmin = false,
    this.fcmToken,
  });

  factory StudentModel.fromMap(String uid, Map<String, dynamic> map) {
    return StudentModel(
      uid: uid,
      name: map['name'] ?? '',
      email: map['email'] ?? '',
      photoUrl: map['photoUrl'],
      rollNumber: map['rollNumber'],
      course: map['course'],
      year: map['year'],
      isAdmin: map['isAdmin'] ?? false,
      fcmToken: map['fcmToken'],
    );
  }

  Map<String, dynamic> toMap() => {
        'name': name,
        'email': email,
        'photoUrl': photoUrl,
        'rollNumber': rollNumber,
        'course': course,
        'year': year,
        'isAdmin': isAdmin,
        'fcmToken': fcmToken,
        'updatedAt': FieldValue.serverTimestamp(),
      };
}

/// ---------- Exam ----------
class ExamModel {
  final String id;
  final String title;
  final String examCode;
  final String subject;
  final int durationMinutes;
  final DateTime scheduledStart;
  final DateTime scheduledEnd;
  final int totalQuestions;
  final int totalMarks;
  final bool showScoreImmediately;
  final String instructions;
  final String createdBy;
  final bool isPublished;

  ExamModel({
    required this.id,
    required this.title,
    required this.examCode,
    required this.subject,
    required this.durationMinutes,
    required this.scheduledStart,
    required this.scheduledEnd,
    required this.totalQuestions,
    required this.totalMarks,
    required this.showScoreImmediately,
    required this.instructions,
    required this.createdBy,
    this.isPublished = true,
  });

  factory ExamModel.fromMap(String id, Map<String, dynamic> map) {
    return ExamModel(
      id: id,
      title: map['title'] ?? '',
      examCode: map['examCode'] ?? '',
      subject: map['subject'] ?? '',
      durationMinutes: map['durationMinutes'] ?? 30,
      scheduledStart: (map['scheduledStart'] as Timestamp).toDate(),
      scheduledEnd: (map['scheduledEnd'] as Timestamp).toDate(),
      totalQuestions: map['totalQuestions'] ?? 0,
      totalMarks: map['totalMarks'] ?? 0,
      showScoreImmediately: map['showScoreImmediately'] ?? true,
      instructions: map['instructions'] ?? '',
      createdBy: map['createdBy'] ?? '',
      isPublished: map['isPublished'] ?? true,
    );
  }

  Map<String, dynamic> toMap() => {
        'title': title,
        'examCode': examCode,
        'subject': subject,
        'durationMinutes': durationMinutes,
        'scheduledStart': Timestamp.fromDate(scheduledStart),
        'scheduledEnd': Timestamp.fromDate(scheduledEnd),
        'totalQuestions': totalQuestions,
        'totalMarks': totalMarks,
        'showScoreImmediately': showScoreImmediately,
        'instructions': instructions,
        'createdBy': createdBy,
        'isPublished': isPublished,
        'createdAt': FieldValue.serverTimestamp(),
      };

  bool get isLive {
    final now = DateTime.now();
    return now.isAfter(scheduledStart) && now.isBefore(scheduledEnd);
  }

  bool get isUpcoming => DateTime.now().isBefore(scheduledStart);
  bool get isExpired => DateTime.now().isAfter(scheduledEnd);
}

/// ---------- MCQ Question ----------
class QuestionModel {
  final String id;
  final String examId;
  final String questionText;
  final List<String> options; // exactly 4 options
  final int correctOptionIndex; // 0-3, never sent to client during exam
  final int marks;
  final int order;

  QuestionModel({
    required this.id,
    required this.examId,
    required this.questionText,
    required this.options,
    required this.correctOptionIndex,
    required this.marks,
    required this.order,
  });

  factory QuestionModel.fromMap(String id, Map<String, dynamic> map) {
    return QuestionModel(
      id: id,
      examId: map['examId'] ?? '',
      questionText: map['questionText'] ?? '',
      options: List<String>.from(map['options'] ?? []),
      correctOptionIndex: map['correctOptionIndex'] ?? 0,
      marks: map['marks'] ?? 1,
      order: map['order'] ?? 0,
    );
  }

  Map<String, dynamic> toMap() => {
        'examId': examId,
        'questionText': questionText,
        'options': options,
        'correctOptionIndex': correctOptionIndex,
        'marks': marks,
        'order': order,
      };

  /// Version safe to send to a student client mid-exam (no answer key).
  Map<String, dynamic> toStudentSafeMap() => {
        'id': id,
        'questionText': questionText,
        'options': options,
        'marks': marks,
        'order': order,
      };
}

/// ---------- Exam Attempt / Result ----------
class ExamAttemptModel {
  final String id;
  final String examId;
  final String studentUid;
  final DateTime startedAt;
  DateTime? submittedAt;
  Map<String, int> answers; // questionId -> selected option index
  int? score;
  bool isSubmitted;
  bool autoSubmitted;

  ExamAttemptModel({
    required this.id,
    required this.examId,
    required this.studentUid,
    required this.startedAt,
    this.submittedAt,
    Map<String, int>? answers,
    this.score,
    this.isSubmitted = false,
    this.autoSubmitted = false,
  }) : answers = answers ?? {};

  factory ExamAttemptModel.fromMap(String id, Map<String, dynamic> map) {
    return ExamAttemptModel(
      id: id,
      examId: map['examId'] ?? '',
      studentUid: map['studentUid'] ?? '',
      startedAt: (map['startedAt'] as Timestamp).toDate(),
      submittedAt: map['submittedAt'] != null ? (map['submittedAt'] as Timestamp).toDate() : null,
      answers: Map<String, int>.from(map['answers'] ?? {}),
      score: map['score'],
      isSubmitted: map['isSubmitted'] ?? false,
      autoSubmitted: map['autoSubmitted'] ?? false,
    );
  }

  Map<String, dynamic> toMap() => {
        'examId': examId,
        'studentUid': studentUid,
        'startedAt': Timestamp.fromDate(startedAt),
        'submittedAt': submittedAt != null ? Timestamp.fromDate(submittedAt!) : null,
        'answers': answers,
        'score': score,
        'isSubmitted': isSubmitted,
        'autoSubmitted': autoSubmitted,
      };
}

/// ---------- Announcement / Notice ----------
class AnnouncementModel {
  final String id;
  final String title;
  final String body;
  final String category; // "notice", "news", "event", "emergency"
  final DateTime postedAt;
  final String postedBy;
  final String? attachmentUrl;

  AnnouncementModel({
    required this.id,
    required this.title,
    required this.body,
    required this.category,
    required this.postedAt,
    required this.postedBy,
    this.attachmentUrl,
  });

  factory AnnouncementModel.fromMap(String id, Map<String, dynamic> map) {
    return AnnouncementModel(
      id: id,
      title: map['title'] ?? '',
      body: map['body'] ?? '',
      category: map['category'] ?? 'notice',
      postedAt: (map['postedAt'] as Timestamp).toDate(),
      postedBy: map['postedBy'] ?? '',
      attachmentUrl: map['attachmentUrl'],
    );
  }

  Map<String, dynamic> toMap() => {
        'title': title,
        'body': body,
        'category': category,
        'postedAt': FieldValue.serverTimestamp(),
        'postedBy': postedBy,
        'attachmentUrl': attachmentUrl,
      };
}

/// ---------- Study Material ----------
class StudyMaterialModel {
  final String id;
  final String title;
  final String subject;
  final String fileUrl;
  final String fileType; // "pdf", "doc", "ppt"
  final DateTime uploadedAt;
  final String uploadedBy;

  StudyMaterialModel({
    required this.id,
    required this.title,
    required this.subject,
    required this.fileUrl,
    required this.fileType,
    required this.uploadedAt,
    required this.uploadedBy,
  });

  factory StudyMaterialModel.fromMap(String id, Map<String, dynamic> map) {
    return StudyMaterialModel(
      id: id,
      title: map['title'] ?? '',
      subject: map['subject'] ?? '',
      fileUrl: map['fileUrl'] ?? '',
      fileType: map['fileType'] ?? 'pdf',
      uploadedAt: (map['uploadedAt'] as Timestamp).toDate(),
      uploadedBy: map['uploadedBy'] ?? '',
    );
  }

  Map<String, dynamic> toMap() => {
        'title': title,
        'subject': subject,
        'fileUrl': fileUrl,
        'fileType': fileType,
        'uploadedAt': FieldValue.serverTimestamp(),
        'uploadedBy': uploadedBy,
      };
}
