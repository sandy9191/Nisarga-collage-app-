import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/models.dart';

/// Centralizes all Firestore reads/writes so screens stay thin.
/// Collections:
///   students/{uid}
///   exams/{examId}
///   exams/{examId}/questions/{questionId}
///   examAttempts/{attemptId}
///   announcements/{id}
///   studyMaterials/{id}
class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  // ---------- Exams ----------

  /// Students find an exam by its 6-character code. Codes are stored
  /// uppercase for consistent lookups.
  Future<ExamModel?> findExamByCode(String code) async {
    final query = await _db
        .collection('exams')
        .where('examCode', isEqualTo: code.toUpperCase())
        .where('isPublished', isEqualTo: true)
        .limit(1)
        .get();
    if (query.docs.isEmpty) return null;
    final doc = query.docs.first;
    return ExamModel.fromMap(doc.id, doc.data());
  }

  Future<List<QuestionModel>> getExamQuestions(String examId) async {
    final snap = await _db
        .collection('exams')
        .doc(examId)
        .collection('questions')
        .orderBy('order')
        .get();
    return snap.docs.map((d) => QuestionModel.fromMap(d.id, d.data())).toList();
  }

  Stream<List<ExamModel>> streamUpcomingExams() {
    final now = Timestamp.now();
    return _db
        .collection('exams')
        .where('isPublished', isEqualTo: true)
        .where('scheduledEnd', isGreaterThan: now)
        .orderBy('scheduledEnd')
        .snapshots()
        .map((s) => s.docs.map((d) => ExamModel.fromMap(d.id, d.data())).toList());
  }

  // ---------- Exam Attempts (the actual test-taking flow) ----------

  /// Starts (or resumes) an attempt. Prevents a second attempt once
  /// one has already been submitted for this exam.
  Future<ExamAttemptModel> startOrResumeAttempt({
    required String examId,
    required String studentUid,
  }) async {
    final existing = await _db
        .collection('examAttempts')
        .where('examId', isEqualTo: examId)
        .where('studentUid', isEqualTo: studentUid)
        .limit(1)
        .get();

    if (existing.docs.isNotEmpty) {
      final doc = existing.docs.first;
      return ExamAttemptModel.fromMap(doc.id, doc.data());
    }

    final attempt = ExamAttemptModel(
      id: '', // Firestore will assign
      examId: examId,
      studentUid: studentUid,
      startedAt: DateTime.now(),
    );
    final ref = await _db.collection('examAttempts').add(attempt.toMap());
    return ExamAttemptModel.fromMap(ref.id, attempt.toMap());
  }

  /// Auto-save a single answer as the student selects it — called on
  /// every option tap so nothing is lost if the app is killed.
  Future<void> saveAnswer({
    required String attemptId,
    required String questionId,
    required int selectedOptionIndex,
  }) async {
    await _db.collection('examAttempts').doc(attemptId).update({
      'answers.$questionId': selectedOptionIndex,
    });
  }

  /// Grades and finalizes the attempt. Called either by the student
  /// tapping Submit, or automatically when the timer hits zero.
  Future<int> submitAttempt({
    required String attemptId,
    required List<QuestionModel> questions,
    required Map<String, int> answers,
    required bool autoSubmitted,
  }) async {
    int score = 0;
    for (final q in questions) {
      final chosen = answers[q.id];
      if (chosen != null && chosen == q.correctOptionIndex) {
        score += q.marks;
      }
    }

    await _db.collection('examAttempts').doc(attemptId).update({
      'answers': answers,
      'score': score,
      'isSubmitted': true,
      'autoSubmitted': autoSubmitted,
      'submittedAt': FieldValue.serverTimestamp(),
    });

    return score;
  }

  // ---------- Announcements ----------

  Stream<List<AnnouncementModel>> streamAnnouncements({int limit = 20}) {
    return _db
        .collection('announcements')
        .orderBy('postedAt', descending: true)
        .limit(limit)
        .snapshots()
        .map((s) => s.docs.map((d) => AnnouncementModel.fromMap(d.id, d.data())).toList());
  }

  Stream<AnnouncementModel?> streamActiveEmergencyNotice() {
    return _db
        .collection('announcements')
        .where('category', isEqualTo: 'emergency')
        .orderBy('postedAt', descending: true)
        .limit(1)
        .snapshots()
        .map((s) => s.docs.isEmpty ? null : AnnouncementModel.fromMap(s.docs.first.id, s.docs.first.data()));
  }

  // ---------- Study Materials ----------

  Stream<List<StudyMaterialModel>> streamStudyMaterials({String? subject}) {
    Query<Map<String, dynamic>> query = _db.collection('studyMaterials').orderBy('uploadedAt', descending: true);
    if (subject != null) {
      query = query.where('subject', isEqualTo: subject);
    }
    return query.snapshots().map(
          (s) => s.docs.map((d) => StudyMaterialModel.fromMap(d.id, d.data())).toList(),
        );
  }

  // ---------- Admin: create exam + bulk questions ----------

  Future<String> createExam(ExamModel exam) async {
    final ref = await _db.collection('exams').add(exam.toMap());
    return ref.id;
  }

  Future<void> addQuestion(String examId, QuestionModel question) async {
    await _db.collection('exams').doc(examId).collection('questions').add(question.toMap());
  }

  Future<void> postAnnouncement(AnnouncementModel announcement) async {
    await _db.collection('announcements').add(announcement.toMap());
  }
}
