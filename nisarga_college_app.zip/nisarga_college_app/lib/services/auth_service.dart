import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_sign_in/google_sign_in.dart';
import '../models/models.dart';

/// Handles Google Sign-In through Firebase Auth and keeps the
/// corresponding `students/{uid}` Firestore document in sync.
class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn(
    scopes: ['email', 'profile'],
  );
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  User? get currentUser => _auth.currentUser;
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  /// Signs the user in with their Google account, creating a
  /// `students/{uid}` document on first login.
  Future<StudentModel?> signInWithGoogle() async {
    final googleUser = await _googleSignIn.signIn();
    if (googleUser == null) return null; // user cancelled

    final googleAuth = await googleUser.authentication;
    final credential = GoogleAuthProvider.credential(
      accessToken: googleAuth.accessToken,
      idToken: googleAuth.idToken,
    );

    final userCredential = await _auth.signInWithCredential(credential);
    final user = userCredential.user;
    if (user == null) return null;

    final docRef = _db.collection('students').doc(user.uid);
    final doc = await docRef.get();

    if (!doc.exists) {
      final newStudent = StudentModel(
        uid: user.uid,
        name: user.displayName ?? 'Student',
        email: user.email ?? '',
        photoUrl: user.photoURL,
      );
      await docRef.set(newStudent.toMap());
      return newStudent;
    }

    return StudentModel.fromMap(user.uid, doc.data()!);
  }

  Future<StudentModel?> fetchStudentProfile(String uid) async {
    final doc = await _db.collection('students').doc(uid).get();
    if (!doc.exists) return null;
    return StudentModel.fromMap(uid, doc.data()!);
  }

  Future<void> signOut() async {
    await _googleSignIn.signOut();
    await _auth.signOut();
  }
}
