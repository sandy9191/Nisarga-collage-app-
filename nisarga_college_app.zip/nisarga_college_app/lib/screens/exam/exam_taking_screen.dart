import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../models/models.dart';
import '../../services/firestore_service.dart';
import '../../theme/app_theme.dart';
import 'exam_result_screen.dart';

class ExamTakingScreen extends StatefulWidget {
  final ExamModel exam;
  final StudentModel student;
  const ExamTakingScreen({super.key, required this.exam, required this.student});

  @override
  State<ExamTakingScreen> createState() => _ExamTakingScreenState();
}

class _ExamTakingScreenState extends State<ExamTakingScreen> {
  final _firestore = FirestoreService();
  final _pageController = PageController();

  List<QuestionModel> _questions = [];
  ExamAttemptModel? _attempt;
  Map<String, int> _localAnswers = {}; // questionId -> selected index, kept locally for instant UI
  int _currentIndex = 0;
  bool _isLoading = true;
  bool _isSubmitting = false;

  late Duration _remaining;
  Timer? _ticker;

  @override
  void initState() {
    super.initState();
    // Lock to the remaining time from exam.scheduledEnd, capped by durationMinutes,
    // so a late joiner can't get the full duration past the scheduled end.
    _bootstrapAttempt();
  }

  Future<void> _bootstrapAttempt() async {
    final attempt = await _firestore.startOrResumeAttempt(
      examId: widget.exam.id,
      studentUid: widget.student.uid,
    );
    final questions = await _firestore.getExamQuestions(widget.exam.id);

    final elapsedSinceStart = DateTime.now().difference(attempt.startedAt);
    final allowedDuration = Duration(minutes: widget.exam.durationMinutes);
    final timeLeftInDuration = allowedDuration - elapsedSinceStart;
    final timeLeftInWindow = widget.exam.scheduledEnd.difference(DateTime.now());
    final effectiveRemaining = timeLeftInDuration < timeLeftInWindow ? timeLeftInDuration : timeLeftInWindow;

    setState(() {
      _attempt = attempt;
      _questions = questions;
      _localAnswers = Map.from(attempt.answers);
      _remaining = effectiveRemaining.isNegative ? Duration.zero : effectiveRemaining;
      _isLoading = false;
    });

    if (_remaining == Duration.zero) {
      _autoSubmit();
    } else {
      _startTicker();
    }
  }

  void _startTicker() {
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      setState(() {
        _remaining -= const Duration(seconds: 1);
      });
      if (_remaining <= Duration.zero) {
        _ticker?.cancel();
        _autoSubmit();
      }
    });
  }

  Future<void> _selectAnswer(String questionId, int optionIndex) async {
    setState(() => _localAnswers[questionId] = optionIndex);
    // Auto-save immediately so progress survives an app kill or crash.
    await _firestore.saveAnswer(
      attemptId: _attempt!.id,
      questionId: questionId,
      selectedOptionIndex: optionIndex,
    );
  }

  Future<void> _submit({required bool autoSubmitted}) async {
    if (_isSubmitting) return;
    setState(() => _isSubmitting = true);
    _ticker?.cancel();

    final score = await _firestore.submitAttempt(
      attemptId: _attempt!.id,
      questions: _questions,
      answers: _localAnswers,
      autoSubmitted: autoSubmitted,
    );

    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => ExamResultScreen(
          exam: widget.exam,
          score: score,
          totalMarks: widget.exam.totalMarks,
          autoSubmitted: autoSubmitted,
        ),
      ),
    );
  }

  void _autoSubmit() => _submit(autoSubmitted: true);

  Future<void> _confirmManualSubmit() async {
    final unanswered = _questions.where((q) => !_localAnswers.containsKey(q.id)).length;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Submit exam?'),
        content: Text(unanswered == 0
            ? 'You have answered all questions. Submit now?'
            : 'You have $unanswered unanswered question(s). Submit anyway?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Submit')),
        ],
      ),
    );
    if (confirmed == true) _submit(autoSubmitted: false);
  }

  String _formatDuration(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  void dispose() {
    _ticker?.cancel();
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (_questions.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: Text(widget.exam.title)),
        body: const Center(child: Text('No questions found for this exam.')),
      );
    }

    final lowTime = _remaining.inSeconds <= 60;

    return PopScope(
      canPop: false, // prevent accidental back-navigation mid-exam
      child: Scaffold(
        appBar: AppBar(
          title: Text(widget.exam.title),
          automaticallyImplyLeading: false,
          actions: [
            Container(
              margin: const EdgeInsets.only(right: 16),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                color: lowTime ? AppColors.danger.withOpacity(0.12) : AppColors.lightGreen,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                children: [
                  Icon(Icons.timer_outlined, size: 16, color: lowTime ? AppColors.danger : AppColors.primaryGreen),
                  const SizedBox(width: 6),
                  Text(
                    _formatDuration(_remaining),
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                      color: lowTime ? AppColors.danger : AppColors.primaryGreen,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        body: Column(
          children: [
            LinearProgressIndicator(
              value: (_currentIndex + 1) / _questions.length,
              backgroundColor: AppColors.lightGreen,
              color: AppColors.primaryGreen,
              minHeight: 4,
            ),
            Expanded(
              child: PageView.builder(
                controller: _pageController,
                physics: const NeverScrollableScrollPhysics(), // force use of Next/Previous
                itemCount: _questions.length,
                onPageChanged: (i) => setState(() => _currentIndex = i),
                itemBuilder: (context, i) => _buildQuestionPage(_questions[i], i),
              ),
            ),
            _buildNavBar(),
          ],
        ),
      ),
    );
  }

  Widget _buildQuestionPage(QuestionModel q, int index) {
    final selected = _localAnswers[q.id];
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Question ${index + 1} of ${_questions.length}', style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
          const SizedBox(height: 8),
          Text(q.questionText, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600, height: 1.4)),
          const SizedBox(height: 8),
          Text('${q.marks} mark${q.marks == 1 ? '' : 's'}', style: const TextStyle(color: AppColors.primaryGreen, fontSize: 12, fontWeight: FontWeight.w600)),
          const SizedBox(height: 20),
          ...List.generate(q.options.length, (i) {
            final isSelected = selected == i;
            return Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: InkWell(
                borderRadius: BorderRadius.circular(14),
                onTap: () => _selectAnswer(q.id, i),
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: isSelected ? AppColors.lightGreen : AppColors.surface,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: isSelected ? AppColors.primaryGreen : Colors.grey.shade300,
                      width: isSelected ? 2 : 1,
                    ),
                  ),
                  child: Row(
                    children: [
                      CircleAvatar(
                        radius: 12,
                        backgroundColor: isSelected ? AppColors.primaryGreen : Colors.grey.shade200,
                        child: Text(
                          String.fromCharCode(65 + i), // A, B, C, D
                          style: TextStyle(fontSize: 12, color: isSelected ? Colors.white : AppColors.textSecondary),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(child: Text(q.options[i], style: const TextStyle(fontSize: 14))),
                    ],
                  ),
                ),
              ),
            );
          }),
        ],
      ),
    );
  }

  Widget _buildNavBar() {
    final isLast = _currentIndex == _questions.length - 1;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8, offset: const Offset(0, -2))],
      ),
      child: Row(
        children: [
          if (_currentIndex > 0)
            Expanded(
              child: OutlinedButton(
                onPressed: () => _pageController.previousPage(
                  duration: const Duration(milliseconds: 250),
                  curve: Curves.easeOut,
                ),
                child: const Text('Previous'),
              ),
            ),
          if (_currentIndex > 0) const SizedBox(width: 12),
          Expanded(
            flex: 2,
            child: ElevatedButton(
              onPressed: _isSubmitting
                  ? null
                  : isLast
                      ? _confirmManualSubmit
                      : () => _pageController.nextPage(
                            duration: const Duration(milliseconds: 250),
                            curve: Curves.easeOut,
                          ),
              style: isLast
                  ? ElevatedButton.styleFrom(backgroundColor: AppColors.deepGreen)
                  : null,
              child: Text(isLast ? 'Submit Exam' : 'Next'),
            ),
          ),
        ],
      ),
    );
  }
}
