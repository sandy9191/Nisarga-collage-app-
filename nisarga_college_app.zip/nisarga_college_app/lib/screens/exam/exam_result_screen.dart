import 'package:flutter/material.dart';
import '../../models/models.dart';
import '../../theme/app_theme.dart';

class ExamResultScreen extends StatelessWidget {
  final ExamModel exam;
  final int score;
  final int totalMarks;
  final bool autoSubmitted;

  const ExamResultScreen({
    super.key,
    required this.exam,
    required this.score,
    required this.totalMarks,
    required this.autoSubmitted,
  });

  @override
  Widget build(BuildContext context) {
    final percent = totalMarks == 0 ? 0.0 : score / totalMarks;

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                autoSubmitted ? Icons.timer_off_rounded : Icons.check_circle_rounded,
                size: 64,
                color: autoSubmitted ? AppColors.accentGold : AppColors.success,
              ),
              const SizedBox(height: 16),
              Text(
                autoSubmitted ? 'Time\'s up — auto-submitted' : 'Exam submitted!',
                style: Theme.of(context).textTheme.headlineSmall,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              Text(exam.title, style: Theme.of(context).textTheme.bodyMedium, textAlign: TextAlign.center),
              const SizedBox(height: 32),
              if (exam.showScoreImmediately) ...[
                Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: AppColors.lightGreen,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Column(
                    children: [
                      Text(
                        '$score / $totalMarks',
                        style: const TextStyle(fontSize: 36, fontWeight: FontWeight.w800, color: AppColors.deepGreen),
                      ),
                      const SizedBox(height: 4),
                      Text('${(percent * 100).toStringAsFixed(0)}% score', style: const TextStyle(color: AppColors.textSecondary)),
                    ],
                  ),
                ),
              ] else ...[
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: AppColors.lightGreen,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: const Text(
                    'Your response has been recorded. Results will be published by your instructor.',
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
              const SizedBox(height: 32),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => Navigator.of(context).popUntil((r) => r.isFirst),
                  child: const Text('Back to Home'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
