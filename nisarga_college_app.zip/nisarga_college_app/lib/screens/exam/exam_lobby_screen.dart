import 'dart:async';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../models/models.dart';
import '../../services/firestore_service.dart';
import '../../theme/app_theme.dart';
import 'exam_taking_screen.dart';

class ExamLobbyScreen extends StatefulWidget {
  final StudentModel student;
  const ExamLobbyScreen({super.key, required this.student});

  @override
  State<ExamLobbyScreen> createState() => _ExamLobbyScreenState();
}

class _ExamLobbyScreenState extends State<ExamLobbyScreen> {
  final _codeController = TextEditingController();
  final _firestore = FirestoreService();
  ExamModel? _foundExam;
  bool _isSearching = false;
  String? _error;
  Timer? _clockTimer;

  @override
  void initState() {
    super.initState();
    // Refresh the countdown / live-status UI every second while an exam is loaded.
    _clockTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted && _foundExam != null) setState(() {});
    });
  }

  @override
  void dispose() {
    _clockTimer?.cancel();
    _codeController.dispose();
    super.dispose();
  }

  Future<void> _searchExam() async {
    final code = _codeController.text.trim();
    if (code.isEmpty) return;
    setState(() {
      _isSearching = true;
      _error = null;
      _foundExam = null;
    });
    try {
      final exam = await _firestore.findExamByCode(code);
      setState(() {
        _foundExam = exam;
        _isSearching = false;
        if (exam == null) _error = 'No exam found for code "$code". Check with your instructor.';
      });
    } catch (e) {
      setState(() {
        _isSearching = false;
        _error = 'Something went wrong. Please try again.';
      });
    }
  }

  void _enterExam() {
    if (_foundExam == null) return;
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ExamTakingScreen(exam: _foundExam!, student: widget.student),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Exam Lobby')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Enter Exam Code', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            Text(
              'Your instructor will share a 6-character code before the exam begins.',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _codeController,
                    textCapitalization: TextCapitalization.characters,
                    maxLength: 6,
                    decoration: const InputDecoration(
                      hintText: 'e.g. AB12CD',
                      counterText: '',
                    ),
                    style: const TextStyle(fontWeight: FontWeight.w700, letterSpacing: 2),
                  ),
                ),
                const SizedBox(width: 12),
                ElevatedButton(
                  onPressed: _isSearching ? null : _searchExam,
                  child: _isSearching
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                        )
                      : const Text('Find'),
                ),
              ],
            ),
            if (_error != null) ...[
              const SizedBox(height: 12),
              Text(_error!, style: const TextStyle(color: AppColors.danger, fontSize: 13)),
            ],
            if (_foundExam != null) ...[
              const SizedBox(height: 24),
              _buildExamCard(_foundExam!),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildExamCard(ExamModel exam) {
    final now = DateTime.now();
    final canStart = exam.isLive;
    final isExpired = exam.isExpired;

    String statusLabel;
    Color statusColor;
    if (isExpired) {
      statusLabel = 'Exam window closed';
      statusColor = AppColors.textSecondary;
    } else if (canStart) {
      statusLabel = 'Live now';
      statusColor = AppColors.success;
    } else {
      statusLabel = 'Starts ${DateFormat('MMM d, h:mm a').format(exam.scheduledStart)}';
      statusColor = AppColors.accentGold;
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(child: Text(exam.title, style: Theme.of(context).textTheme.titleLarge)),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: statusColor.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(statusLabel, style: TextStyle(color: statusColor, fontSize: 11, fontWeight: FontWeight.w600)),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(exam.subject, style: Theme.of(context).textTheme.bodyMedium),
            const Divider(height: 28),
            _infoRow(Icons.timer_outlined, '${exam.durationMinutes} minutes'),
            const SizedBox(height: 10),
            _infoRow(Icons.list_alt_rounded, '${exam.totalQuestions} questions · ${exam.totalMarks} marks'),
            const SizedBox(height: 10),
            _infoRow(
              exam.showScoreImmediately ? Icons.visibility_rounded : Icons.visibility_off_rounded,
              exam.showScoreImmediately ? 'Score shown after submission' : 'Score released by admin later',
            ),
            const SizedBox(height: 20),
            Text('Instructions', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 6),
            Text(exam.instructions.isEmpty ? 'No special instructions provided.' : exam.instructions,
                style: Theme.of(context).textTheme.bodyMedium),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: canStart ? _enterExam : null,
                child: Text(canStart
                    ? 'Start Exam'
                    : isExpired
                        ? 'Exam Closed'
                        : 'Not Started Yet'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _infoRow(IconData icon, String text) {
    return Row(
      children: [
        Icon(icon, size: 18, color: AppColors.primaryGreen),
        const SizedBox(width: 10),
        Text(text, style: const TextStyle(fontSize: 13)),
      ],
    );
  }
}
