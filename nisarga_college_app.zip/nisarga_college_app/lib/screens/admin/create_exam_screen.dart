import 'dart:math';
import 'package:flutter/material.dart';
import '../../models/models.dart';
import '../../services/firestore_service.dart';
import '../../theme/app_theme.dart';

class CreateExamScreen extends StatefulWidget {
  final StudentModel admin;
  const CreateExamScreen({super.key, required this.admin});

  @override
  State<CreateExamScreen> createState() => _CreateExamScreenState();
}

class _CreateExamScreenState extends State<CreateExamScreen> {
  final _firestore = FirestoreService();
  final _titleController = TextEditingController();
  final _subjectController = TextEditingController();
  final _durationController = TextEditingController(text: '30');
  final _instructionsController = TextEditingController();

  DateTime _start = DateTime.now().add(const Duration(hours: 1));
  DateTime _end = DateTime.now().add(const Duration(hours: 2));
  bool _showScore = true;
  bool _isSaving = false;

  final List<_DraftQuestion> _questions = [_DraftQuestion()];

  String _generateExamCode() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no ambiguous chars like O/0, I/1
    final rand = Random();
    return List.generate(6, (_) => chars[rand.nextInt(chars.length)]).join();
  }

  Future<void> _pickDateTime(bool isStart) async {
    final initial = isStart ? _start : _end;
    final date = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (date == null || !mounted) return;
    final time = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(initial));
    if (time == null) return;
    final combined = DateTime(date.year, date.month, date.day, time.hour, time.minute);
    setState(() {
      if (isStart) {
        _start = combined;
      } else {
        _end = combined;
      }
    });
  }

  void _addQuestion() => setState(() => _questions.add(_DraftQuestion()));
  void _removeQuestion(int i) => setState(() => _questions.removeAt(i));

  Future<void> _saveExam() async {
    if (_titleController.text.trim().isEmpty || _subjectController.text.trim().isEmpty) {
      _showSnack('Please fill in the exam title and subject.');
      return;
    }
    if (_questions.any((q) => q.textController.text.trim().isEmpty || q.optionControllers.any((o) => o.text.trim().isEmpty))) {
      _showSnack('Please complete all questions and options before saving.');
      return;
    }

    setState(() => _isSaving = true);
    try {
      final totalMarks = _questions.fold<int>(0, (sum, q) => sum + q.marks);
      final exam = ExamModel(
        id: '',
        title: _titleController.text.trim(),
        examCode: _generateExamCode(),
        subject: _subjectController.text.trim(),
        durationMinutes: int.tryParse(_durationController.text.trim()) ?? 30,
        scheduledStart: _start,
        scheduledEnd: _end,
        totalQuestions: _questions.length,
        totalMarks: totalMarks,
        showScoreImmediately: _showScore,
        instructions: _instructionsController.text.trim(),
        createdBy: widget.admin.uid,
      );

      final examId = await _firestore.createExam(exam);

      for (int i = 0; i < _questions.length; i++) {
        final draft = _questions[i];
        await _firestore.addQuestion(
          examId,
          QuestionModel(
            id: '',
            examId: examId,
            questionText: draft.textController.text.trim(),
            options: draft.optionControllers.map((c) => c.text.trim()).toList(),
            correctOptionIndex: draft.correctIndex,
            marks: draft.marks,
            order: i,
          ),
        );
      }

      if (!mounted) return;
      await showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Exam created!'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Share this code with students:'),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.symmetric(vertical: 14),
                width: double.infinity,
                decoration: BoxDecoration(color: AppColors.lightGreen, borderRadius: BorderRadius.circular(12)),
                child: Text(
                  exam.examCode,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800, letterSpacing: 4, color: AppColors.deepGreen),
                ),
              ),
            ],
          ),
          actions: [
            ElevatedButton(
              onPressed: () {
                Navigator.pop(ctx);
                Navigator.pop(context);
              },
              child: const Text('Done'),
            ),
          ],
        ),
      );
    } catch (e) {
      _showSnack('Failed to save exam. Please try again.');
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  void dispose() {
    _titleController.dispose();
    _subjectController.dispose();
    _durationController.dispose();
    _instructionsController.dispose();
    for (final q in _questions) {
      q.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Create Exam')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          TextField(controller: _titleController, decoration: const InputDecoration(labelText: 'Exam Title')),
          const SizedBox(height: 12),
          TextField(controller: _subjectController, decoration: const InputDecoration(labelText: 'Subject')),
          const SizedBox(height: 12),
          TextField(
            controller: _durationController,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: 'Duration (minutes)'),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(child: _dateTimeTile('Start', _start, () => _pickDateTime(true))),
              const SizedBox(width: 12),
              Expanded(child: _dateTimeTile('End', _end, () => _pickDateTime(false))),
            ],
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _instructionsController,
            maxLines: 3,
            decoration: const InputDecoration(labelText: 'Instructions for students'),
          ),
          const SizedBox(height: 12),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Show score immediately after submission'),
            value: _showScore,
            onChanged: (v) => setState(() => _showScore = v),
          ),
          const Divider(height: 32),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Questions (${_questions.length})', style: Theme.of(context).textTheme.titleMedium),
              TextButton.icon(onPressed: _addQuestion, icon: const Icon(Icons.add), label: const Text('Add Question')),
            ],
          ),
          const SizedBox(height: 8),
          ...List.generate(_questions.length, (i) => _buildQuestionEditor(i)),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _isSaving ? null : _saveExam,
              child: _isSaving
                  ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Text('Save & Generate Exam Code'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _dateTimeTile(String label, DateTime value, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: AppColors.lightGreen.withOpacity(0.4), borderRadius: BorderRadius.circular(14)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
            Text('${value.day}/${value.month}/${value.year}  ${value.hour}:${value.minute.toString().padLeft(2, '0')}',
                style: const TextStyle(fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }

  Widget _buildQuestionEditor(int index) {
    final draft = _questions[index];
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(child: Text('Question ${index + 1}', style: Theme.of(context).textTheme.titleMedium)),
                if (_questions.length > 1)
                  IconButton(onPressed: () => _removeQuestion(index), icon: const Icon(Icons.delete_outline, color: AppColors.danger)),
              ],
            ),
            TextField(controller: draft.textController, decoration: const InputDecoration(labelText: 'Question text')),
            const SizedBox(height: 12),
            ...List.generate(4, (i) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Row(
                  children: [
                    Radio<int>(
                      value: i,
                      groupValue: draft.correctIndex,
                      onChanged: (v) => setState(() => draft.correctIndex = v!),
                      activeColor: AppColors.primaryGreen,
                    ),
                    Expanded(
                      child: TextField(
                        controller: draft.optionControllers[i],
                        decoration: InputDecoration(labelText: 'Option ${String.fromCharCode(65 + i)}'),
                      ),
                    ),
                  ],
                ),
              );
            }),
            Row(
              children: [
                const Text('Marks: '),
                SizedBox(
                  width: 60,
                  child: TextField(
                    keyboardType: TextInputType.number,
                    controller: TextEditingController(text: draft.marks.toString()),
                    onChanged: (v) => draft.marks = int.tryParse(v) ?? 1,
                    decoration: const InputDecoration(isDense: true),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// Local editable state for a question while the admin is building the exam,
/// before it's written to Firestore.
class _DraftQuestion {
  final TextEditingController textController = TextEditingController();
  final List<TextEditingController> optionControllers = List.generate(4, (_) => TextEditingController());
  int correctIndex = 0;
  int marks = 1;

  void dispose() {
    textController.dispose();
    for (final c in optionControllers) {
      c.dispose();
    }
  }
}
