import 'package:flutter/material.dart';
import '../../models/models.dart';
import '../../theme/app_theme.dart';
import 'create_exam_screen.dart';

class AdminDashboardScreen extends StatelessWidget {
  final StudentModel admin;
  const AdminDashboardScreen({super.key, required this.admin});

  static const _actions = [
    _AdminAction('Create Exam', Icons.add_box_rounded, 'create_exam'),
    _AdminAction('Upload Study Material', Icons.upload_file_rounded, 'upload_material'),
    _AdminAction('Publish Results', Icons.publish_rounded, 'publish_results'),
    _AdminAction('Send Notification', Icons.campaign_rounded, 'send_notification'),
    _AdminAction('Manage Students', Icons.groups_rounded, 'manage_students'),
    _AdminAction('Post Notice', Icons.article_rounded, 'post_notice'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Admin Panel')),
      body: GridView.builder(
        padding: const EdgeInsets.all(20),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: 16,
          crossAxisSpacing: 16,
          childAspectRatio: 1.1,
        ),
        itemCount: _actions.length,
        itemBuilder: (context, i) {
          final action = _actions[i];
          return Card(
            child: InkWell(
              borderRadius: BorderRadius.circular(20),
              onTap: () {
                if (action.route == 'create_exam') {
                  Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => CreateExamScreen(admin: admin)),
                  );
                }
                // Other admin actions (upload material, publish results, etc.)
                // follow the same pattern: a dedicated screen using FirestoreService.
              },
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(color: AppColors.lightGreen, borderRadius: BorderRadius.circular(14)),
                      child: Icon(action.icon, color: AppColors.primaryGreen),
                    ),
                    Text(action.label, style: Theme.of(context).textTheme.titleMedium),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _AdminAction {
  final String label;
  final IconData icon;
  final String route;
  const _AdminAction(this.label, this.icon, this.route);
}
