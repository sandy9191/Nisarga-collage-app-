import 'package:flutter/material.dart';
import '../../models/models.dart';
import '../../services/auth_service.dart';
import '../../theme/app_theme.dart';
import '../auth/login_screen.dart';
import '../admin/admin_dashboard_screen.dart';

class ProfileScreen extends StatelessWidget {
  final StudentModel student;
  const ProfileScreen({super.key, required this.student});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Center(
            child: CircleAvatar(
              radius: 44,
              backgroundColor: AppColors.lightGreen,
              backgroundImage: student.photoUrl != null ? NetworkImage(student.photoUrl!) : null,
              child: student.photoUrl == null
                  ? Text(student.name.isNotEmpty ? student.name[0].toUpperCase() : '?',
                      style: const TextStyle(fontSize: 32, color: AppColors.primaryGreen))
                  : null,
            ),
          ),
          const SizedBox(height: 12),
          Text(student.name, style: Theme.of(context).textTheme.titleLarge, textAlign: TextAlign.center),
          Text(student.email, style: Theme.of(context).textTheme.bodyMedium, textAlign: TextAlign.center),
          const SizedBox(height: 24),
          Card(
            child: Column(
              children: [
                _tile(Icons.badge_outlined, 'Roll Number', student.rollNumber ?? 'Not set'),
                const Divider(height: 1),
                _tile(Icons.menu_book_outlined, 'Course', student.course ?? 'Not set'),
                const Divider(height: 1),
                _tile(Icons.calendar_today_outlined, 'Year', student.year ?? 'Not set'),
              ],
            ),
          ),
          const SizedBox(height: 16),
          if (student.isAdmin)
            ListTile(
              leading: const Icon(Icons.admin_panel_settings_rounded, color: AppColors.primaryGreen),
              title: const Text('Admin Panel'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => AdminDashboardScreen(admin: student)),
              ),
            ),
          ListTile(
            leading: const Icon(Icons.dark_mode_outlined),
            title: const Text('Dark Mode'),
            trailing: Switch(value: false, onChanged: (_) {}), // wire to a ThemeProvider in main.dart
          ),
          ListTile(
            leading: const Icon(Icons.contact_support_outlined),
            title: const Text('Contact College'),
            onTap: () {},
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: () async {
              await AuthService().signOut();
              if (context.mounted) {
                Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (_) => const LoginScreen()),
                  (route) => false,
                );
              }
            },
            icon: const Icon(Icons.logout_rounded, color: AppColors.danger),
            label: const Text('Sign Out', style: TextStyle(color: AppColors.danger)),
            style: OutlinedButton.styleFrom(side: const BorderSide(color: AppColors.danger)),
          ),
        ],
      ),
    );
  }

  Widget _tile(IconData icon, String label, String value) {
    return ListTile(
      leading: Icon(icon, color: AppColors.primaryGreen),
      title: Text(label, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
      subtitle: Text(value, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
    );
  }
}
