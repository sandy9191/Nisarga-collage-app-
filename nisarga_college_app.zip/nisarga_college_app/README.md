# Nisarga IND College App — Flutter + Firebase

A Material 3 student/admin app for Nisarga IND College of Science, Arts & Commerce, Bidar —
Google Sign-In, home dashboard, announcements, study materials, and a full timed MCQ
exam engine (join by code → instructions → auto-saved timed exam → auto-submit → result).

This is a **real, runnable Flutter project skeleton** — not a live app. You still need to
connect it to your own Firebase project and build it yourself. Nothing here requires
payment beyond Firebase's free tier for a college-sized user base.

## What's included

```
lib/
  main.dart                          – app entry, auth-state routing
  firebase_options.dart              – PLACEHOLDER, regenerate with flutterfire configure
  theme/app_theme.dart               – Material 3 green/white light+dark theme
  models/models.dart                 – Student, Exam, Question, Attempt, Announcement, StudyMaterial
  services/auth_service.dart         – Google Sign-In + Firebase Auth
  services/firestore_service.dart    – all Firestore reads/writes
  screens/auth/login_screen.dart
  screens/home/home_screen.dart      – quick access grid, announcements, emergency banner
  screens/exam/exam_lobby_screen.dart
  screens/exam/exam_taking_screen.dart   – timer, one-Q-per-page, autosave, auto-submit
  screens/exam/exam_result_screen.dart
  screens/profile/profile_screen.dart
  screens/admin/admin_dashboard_screen.dart
  screens/admin/create_exam_screen.dart  – MCQ builder + exam code generator
firestore.rules                      – role-based security rules
storage.rules                        – file upload rules
pubspec.yaml                         – all dependencies pinned
```

## Screens not yet built out (same pattern, next iteration)

Attendance (QR), Timetable, Assignments, full Notices list, Settings, Results history,
Gallery, Contact page, admin screens for uploading materials / publishing results /
sending notifications / managing students. Each follows the same
`FirestoreService` + Material 3 card pattern already established — happy to build
any of these next, just say which.

## Setup — do this before anything will run

### 1. Install tooling
```bash
# Flutter SDK: https://docs.flutter.dev/get-started/install
flutter --version   # confirm it's installed

npm install -g firebase-tools
firebase login

dart pub global activate flutterfire_cli
```

### 2. Create your Firebase project
Go to https://console.firebase.google.com → **Add project** → name it e.g.
"Nisarga IND College". Enable these products in the console:
- **Authentication** → Sign-in method → enable **Google**
- **Firestore Database** → Create database (start in production mode)
- **Storage** → Get started
- **Cloud Messaging** → already enabled by default

### 3. Connect the app to your project
From the project root:
```bash
cd nisarga_college_app
flutter pub get
flutterfire configure
```
Pick your Firebase project, select Android and iOS, and this **overwrites**
`lib/firebase_options.dart` with your real config. That's the only manual
Firebase step — everything else in the code already points at the right APIs.

### 4. Android-specific
- `flutterfire configure` generates `android/app/google-services.json` automatically.
- Add your SHA-1 fingerprint in Firebase Console → Project Settings → Android app,
  or Google Sign-In will fail silently. Get it with:
  ```bash
  cd android && ./gradlew signingReport
  ```

### 5. iOS-specific
- `flutterfire configure` generates `ios/Runner/GoogleService-Info.plist`.
- Open `ios/Runner.xcworkspace` in Xcode at least once to let CocoaPods resolve.
- Add the reversed client ID URL scheme to `ios/Runner/Info.plist` (Google Sign-In
  docs walk through this exact step: https://pub.dev/packages/google_sign_in#ios-integration).

### 6. Deploy security rules
```bash
firebase deploy --only firestore:rules,storage:rules
```

### 7. Run it
```bash
flutter run
```

### 8. Make yourself an admin
After your first Google sign-in, open Firestore console → `students/{your-uid}` →
manually set `isAdmin: true`. From then on you'll see the Admin Panel entry on
your Profile screen.

## Important security note — read before using for real exams

The current `exams/{examId}/questions/{questionId}` documents store
`correctOptionIndex` on the same document students read to display the MCQ
options. The security rules let any signed-in student **read** that field,
which means a technically curious student could inspect the network traffic
and see answers. Before running a real exam:

- Split questions into two collections: a public one without the answer key
  (`examId/questions/{id}`) and a private one only Cloud Functions/admins can
  read (`examId/answerKey/{id}`).
- Grade submissions server-side with a Cloud Function triggered on
  `examAttempts/{id}` write, instead of grading in `firestore_service.dart`'s
  client-side `submitAttempt`.

This restructure is a half-day task, not a redesign — flagging it now so
nothing "looks done" while quietly leaking answers.

## Firestore schema summary

| Collection | Purpose |
|---|---|
| `students/{uid}` | Profile, `isAdmin` flag, FCM token |
| `exams/{id}` | Title, code, subject, timing window, duration, marks, instructions |
| `exams/{id}/questions/{id}` | MCQ text, 4 options, marks, order (see security note above) |
| `examAttempts/{id}` | One per student per exam: answers map, score, submitted flags |
| `announcements/{id}` | category: notice / news / event / emergency |
| `studyMaterials/{id}` | File metadata + Storage download URL |
| `attendance/{id}` | QR-scan attendance records |

## Next steps I'd suggest

1. Tell me which of the "not yet built" screens matters most and I'll build it next.
2. Get a real Firebase project running with the steps above so you can test the
   exam flow end-to-end.
3. Before any graded exam goes live, do the answer-key split described above.
4. When you're ready for app icons/splash/store listings, that's a separate
   pass (asset generation + `flutter_launcher_icons` config).
